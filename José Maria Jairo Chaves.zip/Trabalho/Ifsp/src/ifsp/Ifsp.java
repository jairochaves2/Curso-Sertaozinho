//******************************************************

//Instituto Federal de São Paulo - Campus Sertãozinho

//Disciplina......: M3LPBD

//Programação de Computadores e Dispositivos Móveis

//Aluno...........: José Maria Jairo Chaves

//******************************************************


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ifsp;

import ifsp.view.Menu;

/**
 *
 * @author jairo
 */
public class Ifsp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Inicia a tela de menu
        new Menu().setVisible(true);
    }
    
}
